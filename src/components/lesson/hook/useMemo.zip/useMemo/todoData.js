export const todoList = [
    {name: "Read book at morning", status: "done"},
    {name: "Read goal", status: "done"},
    {name: "do homework", status: "done"},
    {name: "Work out", status: "pending"},
    {name: "Read at night", status: "pending"},
    {name: "learn code", status: "progress"},
    {name: "learn react", status: "progress"},
    {name: "join class", status: "progress"},
]